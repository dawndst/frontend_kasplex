/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TabId = 'home' | 'products' | 'evm' | 'docs' | 'community';

export interface TokenInfo {
  name: string;
  ticker: string;
  supply: number;
  limit: number;
  deployedAt: string;
  creator: string;
}

export interface MintTransaction {
  id: string;
  type: 'MINT' | 'DEPLOY' | 'TRANSFER';
  asset: string;
  amount?: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  timestamp: string;
}

export interface EcosystemProject {
  id: string;
  name: string;
  category: 'DeFi' | 'NFTs' | 'Infrastructure' | 'Wallets';
  description: string;
  logoUrl: string;
  websiteUrl?: string;
  shares: number;
  likes: number;
}

export interface DocArticle {
  id: string;
  title: string;
  category: 'Core Concepts' | 'Protocol Guides' | 'Resources';
  icon: string;
  summary: string;
  contentMarkdown: string;
}
