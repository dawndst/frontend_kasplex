import { useState } from 'react';
import { TabId, TokenInfo, MintTransaction, EcosystemProject } from './types';
import { INITIAL_TOKENS, INITIAL_TXS, INITIAL_ECOSYSTEM_PROJECTS } from './data';
import { LiveMintingTerminal } from './components/LiveMintingTerminal';
import { DeployTokenForm } from './components/DeployTokenForm';
import { EcosystemBuilders } from './components/EcosystemBuilders';
import { DocumentationHub } from './components/DocumentationHub';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  X, 
  Zap, 
  Layers, 
  ShieldCheck, 
  Cpu, 
  Coins, 
  Database, 
  ArrowRight, 
  Globe, 
  Send, 
  ThumbsUp, 
  PlusCircle, 
  Award,
  Terminal as TermIcon,
  CirclePlay,
  Layers2
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Synchronized global states across panels
  const [tokens, setTokens] = useState<TokenInfo[]>(INITIAL_TOKENS);
  const [transactions, setTransactions] = useState<MintTransaction[]>(INITIAL_TXS);
  const [projects, setProjects] = useState<EcosystemProject[]>(INITIAL_ECOSYSTEM_PROJECTS);

  // Stats derived from states
  const [totalMintsCount, setTotalMintsCount] = useState(128420);
  const [totalVolumeKAS, setTotalVolumeKAS] = useState(482910400);

  // States for zkEVM console simulation
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    'SYSTEM: Initializing zkEVM sequencer v0.2.1-beta...',
    'SYSTEM: Listening on port 8080 for state batches...',
    'SYSTEM: Ready.'
  ]);
  const [isValidating, setIsValidating] = useState(false);

  // Callback to sync new token deployment
  const handleDeploySuccess = (newToken: TokenInfo) => {
    setTokens(prev => [newToken, ...prev]);
  };

  // Callback to sync live transaction feed
  const handleAddTransaction = (newTx: MintTransaction) => {
    setTransactions(prev => {
      // Limit to max 40 items in state to avoid bloating
      const next = [newTx, ...prev];
      if (next.length > 40) {
        return next.slice(0, 40);
      }
      return next;
    });
  };

  // Callback to update stats on mint
  const handleMintSuccess = (ticker: string, amount: number) => {
    setTotalMintsCount(prev => prev + 1);
    // Standard mock multiplier for volume tracking
    setTotalVolumeKAS(prev => prev + Math.floor(amount * 0.1));
  };

  // Callback to add customized project to Ecosystem directory
  const handleAddProject = (newProj: EcosystemProject) => {
    setProjects(prev => [newProj, ...prev]);
  };

  // zkEVM Simulation engine trigger
  const runZkValidationSimulation = () => {
    if (isValidating) return;
    setIsValidating(true);
    setConsoleLogs(prev => [
      ...prev,
      `[${new Date().toLocaleTimeString()}] INCOMING: Batch sequence #804,231 verified. Generating zk-SNARK...`,
    ]);

    setTimeout(() => {
      setConsoleLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] PROVING: Compiling arithmetic circuit with 4,201 gates...`,
      ]);
    }, 1000);

    setTimeout(() => {
      setConsoleLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] PROVING: Validating polynomial commitment...`,
      ]);
    }, 2200);

    setTimeout(() => {
      setConsoleLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] SETTLED: zk-SNARK Validity Proof broadcasted to Kaspa BlockDAG!`,
        `[${new Date().toLocaleTimeString()}] STATUS: Success. L1 anchor gas paid: 0.000184 KAS.`
      ]);
      setIsValidating(false);
    }, 3500);
  };

  return (
    <div className="relative min-h-screen bg-[#121414] text-[#e2e2e2] flex flex-col font-sans overflow-x-hidden">
      
      {/* Absolute top grid background & subtle cyan orb glow */}
      <div className="absolute inset-0 hero-gradient pointer-events-none z-0"></div>
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/45 to-transparent z-10"></div>

      {/* Main Header */}
      <header className="sticky top-0 z-40 bg-[#121414]/80 backdrop-blur-md border-b border-outline-variant/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Logo container */}
          <div 
            onClick={() => setActiveTab('home')} 
            className="flex items-center gap-3 cursor-pointer select-none group"
            id="logo-header-btn"
          >
            <img 
              src="https://lh3.googleusercontent.com/aida/AP1WRLss4K4yVf1brKTkOHT93fmhEYp-h3K2rbBhkAqBM8scrcXvN6jgTac9y7RsSTJut7G6WoAyjm56ZOdx4C-54xMTr0iJFER9XB6xEEjS4lM91I4luHwIwsFOwlidJRYYI9KFQYuvlFK84QfPeUr3wsyXRzR1SjbQXLm80Yhn_U9B1ljSGNtlSJTDX-I-inQulD0_tJCgDDxqKP07uUqIODGQC0SQYd0r-VhWZjn5PoDDydmLxG3XwG2s7rw" 
              alt="Kasplex Logo" 
              className="h-7 w-auto object-contain transition-transform group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1.5 font-headline text-sm font-semibold tracking-wide">
            {(['home', 'products', 'evm', 'docs', 'community'] as TabId[]).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-xl transition-all relative ${
                  activeTab === tab 
                    ? 'text-primary' 
                    : 'text-outline hover:text-[#e2e2e2]'
                }`}
                id={`nav-tab-${tab}`}
              >
                {tab === 'home' && 'Home'}
                {tab === 'products' && 'KRC20 Protocol'}
                {tab === 'evm' && 'zkEVM Layer'}
                {tab === 'docs' && 'Docs'}
                {tab === 'community' && 'Community'}
                
                {activeTab === tab && (
                  <motion.span 
                    layoutId="activeTabUnderline"
                    className="absolute bottom-0 left-4 right-4 h-0.5 bg-primary rounded-full"
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Action Launcher Button */}
          <div className="hidden md:flex items-center gap-3">
            <button 
              onClick={() => setActiveTab('products')} 
              className="px-4 py-2 bg-primary text-background hover:bg-[#8dd2d5] active:scale-[0.97] rounded-xl font-headline font-semibold text-xs tracking-wide transition-all shadow-lg shadow-primary/10 flex items-center gap-1.5"
              id="header-launch-btn"
            >
              <Zap size={13} className="fill-current" />
              Launch Terminal
            </button>
          </div>

          {/* Mobile hamburger menu trigger */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-lg hover:bg-surface-container text-outline hover:text-[#e2e2e2]"
              id="mobile-menu-trigger"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden fixed top-16 left-0 right-0 bg-[#121414]/95 border-b border-outline-variant/50 backdrop-blur-lg z-50 p-4 space-y-2.5 shadow-2xl"
          >
            {(['home', 'products', 'evm', 'docs', 'community'] as TabId[]).map((tab) => (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full text-left px-4 py-2.5 rounded-xl font-headline text-sm font-semibold transition-all ${
                  activeTab === tab 
                    ? 'bg-primary/10 text-primary border border-primary/20' 
                    : 'text-outline hover:bg-surface-container hover:text-[#e2e2e2]'
                }`}
                id={`mobile-tab-${tab}`}
              >
                {tab === 'home' && 'Home'}
                {tab === 'products' && 'KRC20 Protocol'}
                {tab === 'evm' && 'zkEVM Layer'}
                {tab === 'docs' && 'Docs'}
                {tab === 'community' && 'Community'}
              </button>
            ))}
            <button
              onClick={() => {
                setActiveTab('products');
                setIsMobileMenuOpen(false);
              }}
              className="w-full py-3 bg-primary text-background font-headline font-semibold text-xs tracking-wide rounded-xl flex items-center justify-center gap-2"
              id="mobile-action-launch"
            >
              <Zap size={14} className="fill-current" />
              Launch Tokenizer Engine
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Containers */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.28, ease: 'easeInOut' }}
          >
            
            {/* ------------------ 1. HOME SCREEN ------------------ */}
            {activeTab === 'home' && (
              <div id="home-view" className="space-y-16">
                
                {/* Hero section */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-4">
                  <div className="lg:col-span-7 space-y-6">
                    
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-container/10 border border-primary/20 text-primary text-xs font-mono">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
                      Open-Source Meta-Asset Engine
                    </div>

                    <h1 className="font-headline font-black text-4xl sm:text-5xl md:text-6xl text-[#e2e2e2] leading-[1.1] tracking-tight">
                      Empowering Kaspa's <br className="hidden sm:inline" />
                      <span className="text-primary glow-cyan bg-gradient-to-r from-primary to-[#8dd2d5] bg-clip-text text-transparent">Next-Gen Ecosystem</span>
                    </h1>

                    <p className="text-sm sm:text-base text-outline leading-relaxed max-w-xl">
                      Kasplex implements a lightweight, fully decentralized metadata verification protocol to deploy, mint, and manage high-speed custom assets on Kaspa L1 with sub-second settlements and zero inflation.
                    </p>

                    <div className="flex flex-wrap gap-4 pt-2">
                      <button 
                        onClick={() => setActiveTab('products')}
                        className="px-6 py-3 bg-primary text-background hover:bg-[#8dd2d5] font-headline font-semibold text-xs tracking-wider uppercase rounded-xl flex items-center gap-2 transition-all shadow-xl shadow-primary/15 active:scale-[0.98]"
                        id="hero-mint-btn"
                      >
                        Launch KRC-20 Engine
                        <ArrowRight size={14} />
                      </button>

                      <button 
                        onClick={() => setActiveTab('docs')}
                        className="px-6 py-3 bg-surface-container hover:bg-surface-container-high border border-outline-variant hover:border-outline text-[#e2e2e2] font-headline font-semibold text-xs tracking-wider uppercase rounded-xl transition-all"
                        id="hero-docs-btn"
                      >
                        Explore Protocol Docs
                      </button>
                    </div>

                  </div>

                  {/* Hero Right Visual Column */}
                  <div className="lg:col-span-5 relative flex justify-center">
                    <div className="w-full max-w-[420px] aspect-square rounded-2xl overflow-hidden glass-card p-2 border-outline-variant relative group">
                      <img 
                        src="https://lh3.googleusercontent.com/aida/AP1WRLsCIBeiHgd1jfeVKHhp7gmI6nijvFShrjzXnLeIs4_Y6y3X_PyUmBkdF3IrPxc_rjsngUPlGSdve0RI4Js_SOdjuEKObre-DBz8EZUcUOOp0IbJTEYaIMUOqHXzEM9hVKPwdwkg7rc8lG09SDhOpEulqxxTRVODYOS3n30ebx4kusv6_SzCitomynSWQb-GKVb2dXQRbC28vjNFyA0LeAQyco8x7D39sC-oGxkMrhjCg1OpM-VR3jV2dA" 
                        alt="Kasplex Network Visualization" 
                        className="w-full h-full object-cover rounded-xl transition-all duration-700 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#121414] via-transparent to-transparent opacity-60"></div>
                      
                      {/* Live ticker overlay floating badge */}
                      <div className="absolute bottom-4 left-4 right-4 bg-surface-raised/90 backdrop-blur border border-outline-variant rounded-xl p-3 flex items-center justify-between font-mono text-[11px]">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                          <span className="text-outline">Active Blocks:</span>
                          <span className="text-primary font-bold">1 BPS Synced</span>
                        </div>
                        <span className="text-outline-variant">L1 BlockDAG</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Live Statistics Ribbon */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-surface-container/20 p-6 rounded-2xl border border-outline-variant/30">
                  <div className="text-center md:text-left space-y-1">
                    <span className="text-[11px] font-mono text-outline uppercase tracking-wider">Total Transactions</span>
                    <p className="text-2xl font-mono font-black text-primary">15,249,182</p>
                  </div>
                  <div className="text-center md:text-left space-y-1 border-l border-outline-variant/30 pl-4 md:pl-6">
                    <span className="text-[11px] font-mono text-outline uppercase tracking-wider">KRC-20 Mints Committed</span>
                    <p className="text-2xl font-mono font-black text-[#ffb800]">{totalMintsCount.toLocaleString()}</p>
                  </div>
                  <div className="text-center md:text-left space-y-1 border-l border-outline-variant/30 pl-4 md:pl-6">
                    <span className="text-[11px] font-mono text-outline uppercase tracking-wider">Average Network Fee</span>
                    <p className="text-2xl font-mono font-black text-primary">&lt; 0.0001 KAS</p>
                  </div>
                  <div className="text-center md:text-left space-y-1 border-l border-outline-variant/30 pl-4 md:pl-6">
                    <span className="text-[11px] font-mono text-outline uppercase tracking-wider">Volume Transacted</span>
                    <p className="text-2xl font-mono font-black text-primary">{(totalVolumeKAS / 1000).toLocaleString(undefined, { maximumFractionDigits: 1 })}K KAS</p>
                  </div>
                </div>

                {/* Core Features Cards Section */}
                <div className="space-y-6">
                  <div className="text-center max-w-xl mx-auto space-y-2">
                    <h2 className="font-headline font-bold text-2xl text-[#e2e2e2]">Engineered for Hyper-Velocity Scaling</h2>
                    <p className="text-xs text-outline">By combining L1 embedding validation with secondary execution planes, Kasplex achieves absolute decentralization without performance trade-offs.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="glass-card rounded-2xl p-6 border-outline-variant space-y-3 hover:border-primary/50 transition-colors">
                      <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 text-primary flex items-center justify-center">
                        <Layers size={18} />
                      </div>
                      <h3 class="font-headline font-bold text-[#e2e2e2] text-sm uppercase tracking-wide">Ultra-Fast DAG Settlements</h3>
                      <p className="text-xs text-outline leading-relaxed">
                        Inherit 100% of Kaspa’s 1 block-per-second confirmation speed. Transact and mint tokens globally within seconds, completely immune to the slow processing bottlenecks plaguing older PoW ecosystems.
                      </p>
                    </div>

                    <div className="glass-card rounded-2xl p-6 border-outline-variant space-y-3 hover:border-primary/50 transition-colors">
                      <div className="w-10 h-10 rounded-xl bg-[#ffb800]/10 border border-[#ffb800]/20 text-[#ffb800] flex items-center justify-center">
                        <ShieldCheck size={18} />
                      </div>
                      <h3 class="font-headline font-bold text-[#e2e2e2] text-sm uppercase tracking-wide">100% Proof-of-Work Security</h3>
                      <p className="text-xs text-outline leading-relaxed">
                        Meta-assets reside directly within Kaspa L1 UTXO envelopes. State updates are verified via open-source consensus indexers, drawing finality directly from the heavy security of the ASIC hashpower.
                      </p>
                    </div>

                    <div className="glass-card rounded-2xl p-6 border-outline-variant space-y-3 hover:border-primary/50 transition-colors">
                      <div className="w-10 h-10 rounded-xl bg-[#8dd2d5]/10 border border-[#8dd2d5]/20 text-[#8dd2d5] flex items-center justify-center">
                        <Cpu size={18} />
                      </div>
                      <h3 class="font-headline font-bold text-[#e2e2e2] text-sm uppercase tracking-wide">zkEVM Smart Contracts</h3>
                      <p className="text-xs text-outline leading-relaxed">
                        A dedicated virtual machine execution tier compiling off-chain Solidity smart contract loops. Process thousands of complex trades or lending actions with validity proofs settled directly onto L1.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Live Activity Section Header */}
                <div className="space-y-6 pt-4">
                  <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                    <div className="space-y-1.5">
                      <span className="font-mono text-xs text-primary font-bold uppercase tracking-wider">// MEMPOOL AUDITING</span>
                      <h2 className="font-headline font-bold text-2xl text-[#e2e2e2]">Consensus Live Stream</h2>
                      <p className="text-xs text-outline max-w-lg">Observe live operations and smart interactions executed within the decentralized indexer layer across the Kaspa BlockDAG network.</p>
                    </div>
                    <button 
                      onClick={() => {
                        const el = document.getElementById('live-minting-terminal');
                        el?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="px-4 py-2 bg-surface-container hover:bg-surface-container-high border border-outline-variant text-[#e2e2e2] text-xs font-semibold rounded-xl transition-all self-start md:self-auto"
                    >
                      Audit Stream Fullscreen
                    </button>
                  </div>

                  {/* Render the stunning live terminal */}
                  <LiveMintingTerminal 
                    tokens={tokens}
                    transactions={transactions}
                    onAddTransaction={handleAddTransaction}
                    onMintSuccess={handleMintSuccess}
                  />
                </div>

              </div>
            )}

            {/* ------------------ 2. KRC20 PROTOCOL SCREEN ------------------ */}
            {activeTab === 'products' && (
              <div id="products-view" className="space-y-12">
                
                {/* Intro */}
                <div className="max-w-2xl space-y-3">
                  <span className="font-mono text-xs text-primary font-bold uppercase tracking-wider">// KRC-20 PROTOCOL ENGINE</span>
                  <h1 className="font-headline font-black text-3xl sm:text-4xl text-[#e2e2e2]">
                    Fungible Tokenization Engine
                  </h1>
                  <p className="text-sm text-outline leading-relaxed">
                    Deploy standard asset protocols, mint blocks of coins securely, and manage distributed UTXO transactions in a unified interface. Check out the active tokens list and try creating your own!
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Left Column: Deploy Token Form */}
                  <div className="lg:col-span-7">
                    <DeployTokenForm 
                      onDeploySuccess={handleDeploySuccess}
                      onAddTransaction={handleAddTransaction}
                    />
                  </div>

                  {/* Right Column: Active Deployed Tokens List */}
                  <div className="lg:col-span-5 space-y-6">
                    <div className="glass-card rounded-2xl border-outline-variant overflow-hidden">
                      <div className="bg-surface-container px-5 py-4 border-b border-outline-variant flex justify-between items-center">
                        <h4 className="font-headline font-semibold text-sm text-[#e2e2e2] flex items-center gap-2">
                          <Coins size={16} class="text-[#ffb800]" />
                          Active Tickers Registry
                        </h4>
                        <span className="text-[10px] font-mono text-[#ffb800] bg-[#ffb800]/10 border border-[#ffb800]/20 px-2 py-0.5 rounded">
                          {tokens.length} TOKENS
                        </span>
                      </div>

                      <div className="p-4 space-y-3 max-h-[380px] overflow-y-auto custom-scrollbar">
                        {tokens.map((token) => (
                          <div 
                            key={token.ticker}
                            className="bg-surface-container-low/40 border border-outline-variant/30 rounded-xl p-3.5 hover:border-[#ffb800]/50 transition-colors flex justify-between items-start"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-headline font-bold text-sm text-[#e2e2e2]">{token.name}</span>
                                <span className="font-mono text-xs text-primary font-black bg-primary/10 border border-primary/20 px-1.5 py-0.5 rounded">
                                  {token.ticker}
                                </span>
                              </div>
                              <div className="text-[11px] font-mono text-outline space-y-0.5">
                                <div>Max Supply: <span className="text-[#e2e2e2]">{token.supply.toLocaleString()}</span></div>
                                <div>Mint Limit: <span className="text-[#e2e2e2]">{token.limit.toLocaleString()}</span></div>
                              </div>
                            </div>

                            <div className="text-right space-y-2">
                              <span className="text-[10px] text-outline-variant font-mono block">{token.deployedAt}</span>
                              <button
                                onClick={() => {
                                  // Jump to the terminal section or select this token in the mint panel
                                  const selectEl = document.getElementById('mint-ticker-select') as HTMLSelectElement;
                                  if (selectEl) {
                                    selectEl.value = token.ticker;
                                    // Trigger React change manually
                                    const event = new Event('change', { bubbles: true });
                                    selectEl.dispatchEvent(event);
                                  }
                                  // Smooth scroll to the terminal/instant mint panel
                                  const termEl = document.getElementById('live-minting-terminal');
                                  termEl?.scrollIntoView({ behavior: 'smooth' });
                                }}
                                className="px-2.5 py-1 bg-surface-container-high hover:bg-primary hover:text-background text-outline-variant hover:text-background text-[10px] font-mono rounded border border-outline-variant/40 hover:border-transparent transition-all"
                              >
                                Mint {token.ticker}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Protocol visual schematic illustration */}
                    <div className="glass-card rounded-2xl p-5 border-outline-variant flex flex-col justify-between overflow-hidden relative min-h-[160px] group">
                      <div className="absolute -right-8 -bottom-8 w-44 h-44 opacity-25 group-hover:scale-110 transition-transform duration-700 pointer-events-none">
                        <img 
                          src="https://lh3.googleusercontent.com/aida/AP1WRLtZFJN5i9dqiBbRLdHcbB5TkKoDa7I4CZ6Nm3yXUBPrRGL8OF8o20bNvg0e1u4kjckkQ6rLJ0kwABMfHJI9qLR6eOHwZZ-NH-xo81BGMT-VNvZElaFwurM0PVAzchIO6EGfNtpndlkT0pBHviCPkvMvT8syAQpv5aNbP1UEdRY5rRzNcUzveiA3-OijC-GErDq-d_BtEPZgQ9PR8apEwfg151GxFxhCoRajUBpIpzVu8Dkep_TiQ7U1zCw" 
                          alt="KRC-20 Protocol" 
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="space-y-1.5 max-w-xs relative z-10">
                        <span className="font-mono text-[9px] text-[#ffb800] uppercase tracking-wider font-bold">Standard Metatransactions</span>
                        <h4 className="font-headline font-bold text-sm text-[#e2e2e2]">Verification Stack</h4>
                        <p className="text-xs text-outline leading-relaxed">
                          JSON-like instructions are compiled, topological-ordered via Blue Scores, and settled into block headers.
                        </p>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            )}

            {/* ------------------ 3. zkEVM LAYER SCREEN ------------------ */}
            {activeTab === 'evm' && (
              <div id="evm-view" className="space-y-12">
                
                {/* Intro */}
                <div className="max-w-2xl space-y-3">
                  <span className="font-mono text-xs text-primary font-bold uppercase tracking-wider">// Turing-complete virtual execution</span>
                  <h1 className="font-headline font-black text-3xl sm:text-4xl text-[#e2e2e2]">
                    zkEVM Layer Architecture
                  </h1>
                  <p className="text-sm text-outline leading-relaxed">
                    Execute standard Solidity smart contracts, power high-speed decentralized exchanges, and anchor trustless dApps on Kaspa L1 using scalable, math-secured zero-knowledge validity proofs.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
                  
                  {/* Left Column: Stack illustration & Highlights */}
                  <div className="lg:col-span-5 flex flex-col justify-between gap-6">
                    
                    <div className="glass-card rounded-2xl p-5 border-outline-variant flex-1 flex flex-col items-center justify-center relative group min-h-[250px] overflow-hidden">
                      <img 
                        src="https://lh3.googleusercontent.com/aida-public/AB6AXuAzDxnqrayz-NZl8n3js_BxhWgAGSoHDMrkK1yYtISqhE7Qb-hxaqElGitCTOH-UMNQrYLQX5g4x9axpKlHFsiRNmHPehIufK7pjGdPOi8X_JX4_VT6y0JKODQwsevkDvS-bp0UdpAJ-yE7G9BmTVx2VScmE5xHkfkzDCX-v6kXasplLSdCiS3w4S9r_-45eK2kCJbqaqGQ58ne28FeOAWSx-ApIAD8sqORCwCLUMtYXeNTLfCrD3KGvj0-eIgW6ZI_ehG4QF7k170" 
                        alt="EVM Stack Diagram" 
                        className="h-44 w-auto object-contain transition-transform duration-700 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-x-0 bottom-3 text-center">
                        <span className="text-[10px] font-mono text-outline">FIG 1.2: Layer-2 Cryptographic Proof Compiling</span>
                      </div>
                    </div>

                    <div className="bg-surface-container/20 border border-outline-variant/30 rounded-2xl p-5 space-y-3">
                      <h4 className="font-headline font-semibold text-xs text-[#e2e2e2] uppercase tracking-wider flex items-center gap-1.5">
                        <ShieldCheck size={14} class="text-primary" />
                        zkEVM Engine Milestones
                      </h4>
                      
                      <div className="space-y-2.5 font-mono text-xs">
                        <div className="flex justify-between border-b border-outline-variant/10 pb-1.5">
                          <span className="text-outline">Max TPS:</span>
                          <span className="text-primary font-bold">24,500 TPS</span>
                        </div>
                        <div className="flex justify-between border-b border-outline-variant/10 pb-1.5">
                          <span className="text-outline">Proof Proving Time:</span>
                          <span className="text-[#e2e2e2]">~1.8s</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-outline">EVM Compatibility:</span>
                          <span className="text-primary font-bold">100% Solidity v0.8.20</span>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Right Column: Interactive Console Validation Sandbox */}
                  <div className="lg:col-span-7">
                    <div className="glass-card rounded-2xl border-outline-variant overflow-hidden h-full flex flex-col justify-between">
                      
                      <div className="bg-surface-container px-6 py-4 border-b border-outline-variant flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <TermIcon size={16} className="text-[#ffb800]" />
                          <h4 className="font-headline font-semibold text-sm text-[#e2e2e2]">
                            Interactive zk-Proof Validator Console
                          </h4>
                        </div>
                        <span className="inline-flex items-center gap-1.5 text-[10px] font-mono text-[#ffb800] bg-[#ffb800]/10 border border-[#ffb800]/20 px-2 py-0.5 rounded">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#ffb800] animate-pulse"></span>
                          SANDBOX_ACTIVE
                        </span>
                      </div>

                      <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
                        <div className="space-y-2">
                          <p className="text-xs text-outline leading-relaxed">
                            Simulate off-chain state verification within the sandbox. Trigger the validation sequence below to observe how the indexer aggregates transactions, compiles cryptographic validity proofs, and anchors them to Kaspa.
                          </p>

                          {/* Interactive Shell terminal window */}
                          <div className="bg-surface-deep border border-outline-variant rounded-xl p-4 font-mono text-xs text-[#ffb800] space-y-1.5 min-h-[160px] max-h-[220px] overflow-y-auto custom-scrollbar relative">
                            <div className="scanline"></div>
                            {consoleLogs.map((log, idx) => (
                              <div key={idx} className="whitespace-pre-wrap leading-relaxed">
                                {log}
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center justify-between gap-4 pt-2 border-t border-outline-variant/30">
                          <button 
                            onClick={runZkValidationSimulation}
                            disabled={isValidating}
                            className="px-5 py-2.5 bg-[#ffb800] hover:bg-[#ffcd54] text-background disabled:opacity-50 disabled:scale-100 font-headline font-semibold text-xs rounded-xl flex items-center gap-2 transition-all shadow-lg active:scale-[0.98]"
                            id="verify-batch-btn"
                          >
                            {isValidating ? (
                              <>
                                <span className="w-3.5 h-3.5 border-2 border-background border-t-transparent rounded-full animate-spin"></span>
                                Generating Proofs...
                              </>
                            ) : (
                              <>
                                <CirclePlay size={14} />
                                Verify Transaction Batch
                              </>
                            )}
                          </button>

                          <button 
                            onClick={() => setConsoleLogs([
                              'SYSTEM: Console session cleared.',
                              'SYSTEM: Listening on port 8080 for state batches...',
                              'SYSTEM: Ready.'
                            ])}
                            className="px-4 py-2.5 bg-surface-container-high hover:bg-surface-bright text-outline hover:text-[#e2e2e2] text-xs font-semibold rounded-xl border border-outline-variant/40 transition-colors"
                            id="clear-console-btn"
                          >
                            Clear Console
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>

                </div>

                {/* zkEVM Benefits Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="bg-surface-container/20 border border-outline-variant/30 rounded-xl p-5 space-y-2">
                    <span className="font-mono text-xs text-primary font-bold">1. LOW-LATENCY</span>
                    <h5 className="font-headline font-bold text-sm text-[#e2e2e2]">Instant Fraud protection</h5>
                    <p className="text-xs text-outline leading-relaxed">
                      Zero-knowledge cryptography ensures transactions cannot be malicious or altered. No multi-day withdrawal dispute windows like optimistic rollups.
                    </p>
                  </div>

                  <div className="bg-surface-container/20 border border-outline-variant/30 rounded-xl p-5 space-y-2">
                    <span className="font-mono text-xs text-[#ffb800] font-bold">2. MINIMAL FEES</span>
                    <h5 className="font-headline font-bold text-sm text-[#e2e2e2]">Aggregated Rollup Bundles</h5>
                    <p className="text-xs text-outline leading-relaxed">
                      By bundling thousands of EVM transactions off-chain, the high-throughput validator only submits a lightweight proof payload to Kaspa L1, saving massive gas resources.
                    </p>
                  </div>

                  <div className="bg-surface-container/20 border border-outline-variant/30 rounded-xl p-5 space-y-2">
                    <span className="font-mono text-xs text-[#8dd2d5] font-bold">3. SECURE BRIDGE</span>
                    <h5 className="font-headline font-bold text-sm text-[#e2e2e2]">Bridges Built on Math</h5>
                    <p className="text-xs text-outline leading-relaxed">
                      Cryptographic multi-sig lockers verify locked assets from EVM environments, permitting rapid trustless conversions directly to high-speed KRC-20 standards.
                    </p>
                  </div>
                </div>

              </div>
            )}

            {/* ------------------ 4. DOCS SCREEN ------------------ */}
            {activeTab === 'docs' && (
              <div id="docs-view" className="space-y-8">
                <div className="max-w-xl space-y-2">
                  <span className="font-mono text-xs text-primary font-bold uppercase tracking-wider">// L1 DATA SCHEMATICS</span>
                  <h1 className="font-headline font-black text-3xl text-[#e2e2e2]">Protocol Documentation</h1>
                  <p className="text-xs text-outline leading-relaxed">
                    Read the architectural blueprints, technical specifications, and setup instructions detailing how the Kasplex indexer, KRC-20 standard, and zkEVM work.
                  </p>
                </div>

                {/* Render the full-fledged Docs components */}
                <DocumentationHub />
              </div>
            )}

            {/* ------------------ 5. COMMUNITY SCREEN ------------------ */}
            {activeTab === 'community' && (
              <div id="community-view" className="space-y-12">
                
                {/* Intro */}
                <div className="max-w-2xl space-y-3">
                  <span className="font-mono text-xs text-primary font-bold uppercase tracking-wider">// INTEGRATION DIRECTORY</span>
                  <h1 className="font-headline font-black text-3xl sm:text-4xl text-[#e2e2e2]">
                    Kasplex Ecosystem Registry
                  </h1>
                  <p className="text-sm text-outline leading-relaxed">
                    Explore and test the cutting-edge decentralized applications, automated market makers (AMMs), digital artwork collectible markets, and cross-chain gateways building directly on top of the Kasplex protocol.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  {/* Left: Glowing Community Hub Graphic */}
                  <div className="lg:col-span-5 flex justify-center">
                    <div className="w-full max-w-[360px] aspect-square rounded-2xl overflow-hidden glass-card p-2 border-outline-variant relative group">
                      <img 
                        src="https://lh3.googleusercontent.com/aida/AP1WRLspQTlkrOaabzOol2xJNttv02ngoFbiAaGKI9Sbsg7zVV508d-OBahtl-ows9uhI0eWjPJQChxk4kVmTUULXWyqPN8jZRmC2jU3WduLgbrc6VwVSUQrZpfatDstZXxd81hvPbjdNgEgMO2qXqp-PSCWB8JwwM4vL9kIHH8j5djJhKvNu2dHkRbgFJjsNoBtchteoK6TJfpX9Irw1mtSIghJyCkpuAKX-EaiblsumpIxCIebfMcFY6g_-Bs" 
                        alt="Kasplex Community Orb Visual" 
                        className="w-full h-full object-cover rounded-xl transition-transform duration-700 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#121414] via-transparent to-transparent opacity-60"></div>
                      
                      <div className="absolute top-4 left-4 bg-surface-container/90 backdrop-blur border border-outline-variant px-3 py-1 rounded-full text-[10px] text-primary font-mono font-bold flex items-center gap-1.5">
                        <Award size={12} />
                        KASPLEX MAINNET LIVE
                      </div>
                    </div>
                  </div>

                  {/* Right: Community member cards */}
                  <div className="lg:col-span-7 space-y-6">
                    <div className="glass-card rounded-2xl p-6 border-outline-variant space-y-4">
                      <h4 className="font-headline font-bold text-sm text-[#e2e2e2] uppercase tracking-wider flex items-center gap-2">
                        <PlusCircle size={16} className="text-primary" />
                        Pioneering Ecosystem Builders
                      </h4>
                      <p className="text-xs text-outline leading-relaxed">
                        Kasplex empowers developers by maintaining zero centralized sequencing. Here is the active list of builders. Tap Like, copy a project link, or add your own project to grow the Kasplex registry instantly!
                      </p>

                      {/* Community Members Avatars Showcase */}
                      <div className="flex items-center gap-3 bg-surface-container-low/40 p-3 rounded-xl border border-outline-variant/30">
                        <div className="flex -space-x-2">
                          <img 
                            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAIeMbCx2WKpTk6R2zhTsSqujfH6sRwevPnM8xl4K-UlmMB-UyQHwaNKSXMu125UNwA5BI-O-BmMQ43YHBNvcOX63K-Rhw2llia1_OdXtagifm5R60KIKqJOKhlAwAI0QsN0rIo6Q6-E1vXUZw9YMQEG5iT94C_KEGnwnQrVUaVqebsK46EKrL0EDRv6fkz4nSgF-NnsbihQoe7RzXdr-MAMhc4wlaEPrRK3oryufBq4GTol3ri7OHwTP3ZKdYweovMyWTP1Pc9MpQ" 
                            alt="Ecosystem Architect Avatar" 
                            className="w-8 h-8 rounded-full border border-[#121414] object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <img 
                            src="https://lh3.googleusercontent.com/aida-public/AB6AXuD7zUdp8Kl9KiXjMcGiT65GLqgt78N1SyoPMNlEHAMI8YgsgMH6Y2Zgsnc2Yafd-8pMg9NTfNh3mEl-hzfrdhj1GdG1MKa-X6p5SbeMMpgDtqagdJRA1NP21pRjLTTFcIZ-m6xQH95tpQsdxGI261mTb3InYh7cpbksDIoJApbD7_VUwyRtSCgVYISqtAn7xVDr1tclFZPWB_zJCUC5ws6842luIIAOXjyiyWGjzWef52xhW6rv9Q_oh7daf17b4pacUdf7iGAzrJU" 
                            alt="Core Developer Avatar" 
                            className="w-8 h-8 rounded-full border border-[#121414] object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <img 
                            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAdeEeoLL2qr_4FFRihgbnVLpXaoVsBvGk6JIXJDAOOQ57cuhfxG-exMCgEpoUNqp9T58Vvp1xh3B90BPqUjjMcU9skt-dwYB_gLEkrwHbylL3XNKzo5PJJv0U-Coe8vYyaMsvwjWq8g5zPtEv9MuloI1sL-9altCgxN4bLx8eomEUTOgpm2GYFxljbpB160gFCUb1Lr3ylBWOsmh-PBuPEfY3pyK1IjOtGGD_xD9ZDpSy7zDdVq2PHo3TJqvA5-f8SZs7COMWw0VU" 
                            alt="Validator Node Avatar" 
                            className="w-8 h-8 rounded-full border border-[#121414] object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <span className="text-[11px] text-outline font-mono">
                          Join <strong className="text-primary">1,240+ core developers</strong> actively validating blocks.
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Filterable Builders Dashboard Registry Component */}
                <EcosystemBuilders 
                  projects={projects}
                  onAddProject={handleAddProject}
                />

              </div>
            )}

          </motion.div>
        </AnimatePresence>

      </main>

      {/* Main Footer */}
      <footer className="bg-[#0d0f0f] border-t border-outline-variant/30 py-12 relative z-10 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Branding Column */}
            <div className="md:col-span-2 space-y-4">
              <img 
                src="https://lh3.googleusercontent.com/aida/AP1WRLss4K4yVf1brKTkOHT93fmhEYp-h3K2rbBhkAqBM8scrcXvN6jgTac9y7RsSTJut7G6WoAyjm56ZOdx4C-54xMTr0iJFER9XB6xEEjS4lM91I4luHwIwsFOwlidJRYYI9KFQYuvlFK84QfPeUr3wsyXRzR1SjbQXLm80Yhn_U9B1ljSGNtlSJTDX-I-inQulD0_tJCgDDxqKP07uUqIODGQC0SQYd0r-VhWZjn5PoDDydmLxG3XwG2s7rw" 
                alt="Kasplex Logo" 
                className="h-6 w-auto object-contain opacity-80 hover:opacity-100 transition-opacity"
                referrerPolicy="no-referrer"
              />
              <p className="text-xs text-outline max-w-sm leading-relaxed">
                Kasplex is a decentralized indexer and consensus verification framework for launching high-speed meta-assets, KRC-20 fungible tokens, and zkEVM contracts anchored securely on Kaspa PoW GHOSTDAG.
              </p>
            </div>

            {/* Quick Links Column */}
            <div className="space-y-3">
              <h5 className="font-headline font-semibold text-xs text-[#e2e2e2] uppercase tracking-wider">Protocol Hub</h5>
              <div className="flex flex-col gap-2 font-mono text-[11px] text-outline">
                <button onClick={() => setActiveTab('home')} className="text-left hover:text-primary transition-colors">Home Dashboard</button>
                <button onClick={() => setActiveTab('products')} className="text-left hover:text-primary transition-colors">KRC-20 Terminal</button>
                <button onClick={() => setActiveTab('evm')} className="text-left hover:text-primary transition-colors">zkEVM Layer-2</button>
                <button onClick={() => setActiveTab('docs')} className="text-left hover:text-primary transition-colors">Technical Docs</button>
              </div>
            </div>

            {/* Community Links Column */}
            <div className="space-y-3">
              <h5 className="font-headline font-semibold text-xs text-[#e2e2e2] uppercase tracking-wider">Ecosystem Builders</h5>
              <div className="flex flex-col gap-2 font-mono text-[11px] text-outline">
                <button onClick={() => setActiveTab('community')} className="text-left hover:text-primary transition-colors">Partner Directory</button>
                <a href="#" className="text-left hover:text-primary transition-colors flex items-center gap-1.5">
                  <Globe size={11} />
                  Twitter / X
                </a>
                <a href="#" className="text-left hover:text-primary transition-colors flex items-center gap-1.5">
                  <Send size={11} />
                  Telegram Chat
                </a>
              </div>
            </div>
          </div>

          {/* Bottom attribution copyright banner */}
          <div className="border-t border-outline-variant/20 pt-6 mt-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 font-mono text-[10px] text-outline-variant">
            <span>&copy; {new Date().getFullYear()} Kasplex Protocol Team. Released under the Apache 2.0 Open Source License.</span>
            <span className="flex items-center gap-1">
              <span>BlockDAG Synced Height:</span>
              <strong className="text-primary">#48,102,120</strong>
            </span>
          </div>

        </div>
      </footer>

    </div>
  );
}
