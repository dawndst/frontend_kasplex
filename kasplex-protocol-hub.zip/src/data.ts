import { EcosystemProject, DocArticle, TokenInfo, MintTransaction } from './types';

export const INITIAL_ECOSYSTEM_PROJECTS: EcosystemProject[] = [
  {
    id: 'kasswap',
    name: 'KasSwap',
    category: 'DeFi',
    description: 'The native automated market maker (AMM) designed specifically for KRC-20 tokens. Seamlessly swap, add liquidity, and farm yields with minimal transaction fees on Kaspa.',
    logoUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBCxT_JpfIdlZOy8dlwNRt-MYmYpiE6d2opeB1kkIBLop8QRtH7zvY_4h7dadxuEsp5TI-T14s9YpP2VlvkrUQjcem1K2hFMqcItuqeetepnBnutJrXs7Qv35jDYXxHbSpSpXJ3k8H_b2BJ7LGK0QN8Ww3EgOnhVrFG231pdm4ArnLy8ffeSqZncVvJy4wU77e4gxqmPJbNSSybvsn2mp35qCwmJP4j6HuRtbbucCcvo8IHjVUr8pMM8mGTltA-LdxBZYoJ3zRbhQo',
    websiteUrl: '#',
    shares: 1240,
    likes: 854
  },
  {
    id: 'omnivault',
    name: 'OmniVault',
    category: 'Infrastructure',
    description: 'A multi-signature secure vault and non-custodial asset management portal for individual users and institutional builders seeking high-security custody of KRC-20 reserves.',
    logoUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCp_moSMvXYbvGxN8L_C5aKojmLf0U6eBhKZHAe3rS_IdSIMqvQJ3yxDN85604UCcyhXzZCI1CgdDEvtdegDsZW8m_FLjQWUJas6xbvGiM6gf2lZuYesXrBmCq_nZ4_r7ZUxLzxXyA1FkaVR8_D6kPMV1CFCFPiHRODKPHVvH2_WuuZisFrA0UXswfbeDnm1AWX4vx8SLqZpddDQIJl66i3fOf89OotnbN3gwuV4KpNu9ADVW9FDz7W_L5NUGNJADsQptDEHqnNVV0',
    websiteUrl: '#',
    shares: 942,
    likes: 710
  },
  {
    id: 'kasart',
    name: 'KasArt',
    category: 'NFTs',
    description: 'The pioneering open NFT marketplace for exploring, buying, selling, and launching Kasplex KRC-721 digital collectibles with instantaneous settlements and fraction-of-a-cent fees.',
    logoUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3kw6u9k85Y24tv4WK4UHxDsa_BhoK7VZugZSJqLlho2OOmTB_QBBW7Lqanivnb8yNWSDTeh0z14L3IHhi7y3XSQROuDqTf9VOLLBLs8nY0f8iB8xYzvd1w4-u6etp9fDRs7atz8mYHNrLLWchEFnWabHxivVaiwBMylIdixqFwidwPqhdEPB0zGNbSTYLVsHzkdc2-BmPKOXWbeHiMI6dxo0NdRFiPOKpFQ-2cnpmrWuvGqWldMrZc0Gc5vrf5fEWRcbs9FHD080',
    websiteUrl: '#',
    shares: 1843,
    likes: 1205
  },
  {
    id: 'bridgex',
    name: 'BridgeX',
    category: 'Wallets',
    description: 'Cross-chain decentralized asset gateway connecting Kaspa to major EVM ecosystems, allowing trustless wrapping and bridging of major liquid tokens directly to KRC-20.',
    logoUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB7Q9rdNmWfbH_cB6eukU-fc6d8ku6ch7YAkYtGifUV-ppexbzqquSgZXbBECxkHVRRDVmOIJ11sLT3fOqnWgxSJnLeZx_b3fzDPkKiR7EATgTJMYWD3iY1pG94nvNdaGPopEfNO4xXB4h_qfPiNeSlTDddhUEAo0xXmtJxxvzPml-MRp13ZQOOfKd9i69Tn15Qr0B2gFLVOgD0PiDpiPyidSsyQU2ZkWfjAu2dBU7A2KCLU-JTpDvBSkh0yu2f7WaTiP-da0ZIa9k',
    websiteUrl: '#',
    shares: 1102,
    likes: 680
  }
];

export const INITIAL_TOKENS: TokenInfo[] = [
  {
    name: 'Kasplex Native',
    ticker: 'KASP',
    supply: 210000000,
    limit: 1000,
    deployedAt: '2026-03-10 14:32',
    creator: 'kaspa:qp3x...d3z'
  },
  {
    name: 'Giga Hash',
    ticker: 'GHASH',
    supply: 1000000000,
    limit: 10000,
    deployedAt: '2026-04-01 09:12',
    creator: 'kaspa:qr8u...7wx'
  },
  {
    name: 'Nakamoto Tribute',
    ticker: 'SATO',
    supply: 21000000,
    limit: 50,
    deployedAt: '2026-04-18 20:05',
    creator: 'kaspa:qpye...18q'
  },
  {
    name: 'Silver Coin',
    ticker: 'KSLV',
    supply: 84000000,
    limit: 100,
    deployedAt: '2026-05-02 11:45',
    creator: 'kaspa:qzt8...88z'
  }
];

export const INITIAL_TXS: MintTransaction[] = [
  {
    id: 'tx_821d3f2a...9b3c',
    type: 'MINT',
    asset: 'KASP',
    amount: '1,000 KASP',
    status: 'SUCCESS',
    timestamp: 'Just now'
  },
  {
    id: 'tx_a348fe28...dc1a',
    type: 'MINT',
    asset: 'GHASH',
    amount: '10,000 GHASH',
    status: 'SUCCESS',
    timestamp: '2s ago'
  },
  {
    id: 'tx_f921e30a...23ef',
    type: 'DEPLOY',
    asset: 'SATO',
    status: 'SUCCESS',
    timestamp: '15s ago'
  },
  {
    id: 'tx_12bc09ad...ef44',
    type: 'TRANSFER',
    asset: 'KASP',
    amount: '25,000 KASP',
    status: 'PENDING',
    timestamp: '30s ago'
  },
  {
    id: 'tx_8d31a021...b121',
    type: 'MINT',
    asset: 'KSLV',
    amount: '100 KSLV',
    status: 'SUCCESS',
    timestamp: '1m ago'
  }
];

export const DOCS_ARTICLES: DocArticle[] = [
  {
    id: 'introduction',
    category: 'Core Concepts',
    title: 'Welcome to Kasplex',
    icon: 'info',
    summary: 'An open-source decentralized protocol engineered for issuing and managing meta-assets on Kaspa L1.',
    contentMarkdown: `## Introduction to Kasplex

Kasplex is an open-source decentralized protocol engineered specifically for issuing, tracking, and managing meta-assets on **Kaspa L1 (BlockDAG)**. By exploiting Kaspa’s unmatched speed (1 block-per-second, scaling to 10+), Kasplex enables smart, high-performance tokenized assets without modifying Kaspa’s core consensus.

### Why Kasplex?

Traditional layer-1 protocols face severe throughput bottlenecks, skyrocketing gas fees, or centralized sequencing when introducing custom tokens. Kasplex addresses these problems at the root:

*   **Sub-Second Settlements:** Build on Kaspa's BlockDAG architecture to process transactions instantly.
*   **Minimal Gas Overhead:** Transact for mere fractions of a penny.
*   **Full Security Inheritance:** Inherit 100% of the decentralized security of the Kaspa L1 Proof-of-Work hashpower.
*   **Fully Decentralized Indexing:** Open-source indexers verify state transitions deterministically, leaving zero room for frontrunning.

---

### Protocol Architecture

The Kasplex engine consists of three key architectural pillars:

1.  **L1 Data Embedding:** Arbitrary structured data is safely encoded within standard Kaspa UTXO envelopes.
2.  **State Transition Verification:** Decentralized indexers monitor the L1 ledger, compiling the historical BlockDAG state to update account balances.
3.  **zkEVM Expansion:** A secondary computation layer executing zero-knowledge execution templates to support decentralized applications, AMMs, and lending pools without L1 bloat.

\`\`\`
+--------------------------------------------------------+
|                      dApp Layer                        |
|              (KasSwap, KasArt, Wallets)                |
+--------------------------------------------------------+
                           ||
                           v
+--------------------------------------------------------+
|                Kasplex zkEVM Engine                    |
|             (Smart Contract Execution)                 |
+--------------------------------------------------------+
                           ||
                           v
+--------------------------------------------------------+
|               Decentralized Indexer                    |
|             (UTXO State Verification)                  |
+--------------------------------------------------------+
                           ||
                           v
+--------------------------------------------------------+
|                  Kaspa L1 BlockDAG                     |
|                (PoW Data Ingestion)                    |
+--------------------------------------------------------+
\`\`\`
`
  },
  {
    id: 'krc20-standard',
    category: 'Core Concepts',
    title: 'KRC-20 Protocol Specification',
    icon: 'token',
    summary: 'Learn the exact rules governing token deployment, minting, and transfers within the KRC-20 framework.',
    contentMarkdown: `## KRC-20 Token Protocol

The **KRC-20 standard** is the blueprint for fungible token creation on Kaspa. It allows anyone to easily deploy, mint, and transfer tokens by appending light JSON-like transition commands into the Kaspa transaction metadata.

### Core Operations

KRC-20 relies on three elementary command types: \`deploy\`, \`mint\`, and \`transfer\`.

#### 1. Deploy
Registers a new ticker token on-chain. Once successfully broadcasted, the ticker cannot be modified, re-registered, or hijacked.
*   **Ticker requirements:** Exactly 4 to 6 uppercase alphabetic characters (e.g., \`KASP\`, \`GHASH\`).
*   **Parameters:** Max supply, Limit per mint.

#### 2. Mint
Allows any wallet to claim standard chunks of the token up to the specified limit, until the maximum supply is fully saturated.
*   **Fair Launch Mechanics:** No team reserves, pre-allocation, or whitelist limitations unless explicitly coded via smart templates.

#### 3. Transfer
Moves balances from wallet A to wallet B. The Kasplex indexer validates that Wallet A contains a sufficient balance before committing the state update.

---

### Transaction Format Sample

A standard KRC-20 instruction is written as plain UTF-8 text injected into a Kaspa UTXO output:

\`\`\`json
{
  "p": "krc-20",
  "op": "mint",
  "tick": "GHASH",
  "amt": "10000"
}
\`\`\`

Our protocol indexers automatically parse these payloads, ordering them sequentially in accordance with Kaspa's BlockDAG DAG-ordering rules (Blue Score and GHOSTDAG topological sorting).`
  },
  {
    id: 'zkevm',
    category: 'Protocol Guides',
    title: 'zkEVM Smart Contracts',
    icon: 'analytics',
    summary: 'A look into how zero-knowledge rollups enable ultra-fast dApps on Kaspa without compromises.',
    contentMarkdown: `## zkEVM Layer Architecture

To unlock complete Turing-complete programmability, Kasplex implements a tailored **Zero-Knowledge Ethereum Virtual Machine (zkEVM)**. 

### Layer-2 Scaling with Proof-of-Work Security

The zkEVM acts as a scalable execution layer that aggregates thousands of off-chain transactions, compiles them into a single mathematical Proof of Validity, and anchors the proof back on the Kaspa L1 BlockDAG.

### Key Features:

1.  **EVM Compatibility:** Solidity smart contracts can be deployed to Kasplex without modifying a single line of code.
2.  **Ultra-Fast Execution:** Off-chain state transitions are processed at 20,000+ Transactions Per Second (TPS).
3.  **Instant Fraud-Proof Validity:** Zero-knowledge mathematical proofs are verified instantly by any standard Kasplex validator node.
4.  **Shared Liquidity:** Bridge assets seamlessly from Ethereum, Arbitrum, or Solana into the high-performance Kaspa DAG ecosystem.

---

### zkEVM Lifecycle Flow

1.  **User Initiates Transaction:** Signed transactions are submitted to the zkEVM Mempool.
2.  **Sequencer Compiles Blocks:** The Kasplex sequencer bundles transactions, processes local state changes, and generates a block header.
3.  **Prover Generates Proof:** A cryptographic prover generates a zk-SNARK proof verifying the state transition correctness.
4.  **Proof Settlement:** The proof is submitted to Kaspa L1 within a standard payload envelope, establishing permanent, unalterable finality.
`
  },
  {
    id: 'node-setup',
    category: 'Protocol Guides',
    title: 'Indexer & Node Installation',
    icon: 'settings_system_daydream',
    summary: 'Step-by-step instructions for running an independent Kasplex indexer node.',
    contentMarkdown: `## Running a Kasplex Indexer Node

Running your own indexer ensures 100% trustless verification of balances, allows you to query real-time blockchain data without relying on public endpoints, and supports private, rapid transaction submissions.

### System Requirements

*   **Operating System:** Linux (Ubuntu 22.04 LTS or newer recommended)
*   **CPU:** 4 Cores (Intel Core i7 or AMD Ryzen 5 or equivalent)
*   **RAM:** 16 GB DDR4/DDR5
*   **Storage:** 200 GB NVMe SSD (High I/O speed is critical)
*   **Network:** Stable 100 Mbps symmetric connection

---

### Installation Steps

#### 1. Install System Dependencies
Ensure your node environment is up to date and has Docker installed:

\`\`\`bash
sudo apt update && sudo apt upgrade -y
sudo apt install docker.io docker-compose git -y
\`\`\`

#### 2. Clone the Repository
Clone the official open-source Kasplex Indexer:

\`\`\`bash
git clone https://github.com/kasplex/indexer.git
cd indexer
\`\`\`

#### 3. Configure Environmental Variables
Create your configuration environment file:

\`\`\`bash
cp .env.example .env
nano .env
\`\`\`

*Specify your local Kaspa Node (\`kaspad\`) RPC endpoint and database credentials.*

#### 4. Spin Up the Services
Launch the indexer alongside its internal high-speed database:

\`\`\`bash
docker-compose up -d
\`\`\`

You can verify the status of your syncing node using:

\`\`\`bash
docker-compose logs -f --tail=100
\`\`\`
`
  },
  {
    id: 'frequently-asked',
    category: 'Resources',
    title: 'Frequently Asked Questions',
    icon: 'help',
    summary: 'Answers to the most common questions regarding Kasplex mechanics and minting rules.',
    contentMarkdown: `## Frequently Asked Questions

### 1. How is Kasplex different from ERC-20 or BRC-20?
Unlike ERC-20, which runs on a high-fee, single-sequence virtual machine (Ethereum), Kasplex runs on Kaspa's BlockDAG, which permits multiple parallel blocks and provides sub-second finality. 
Unlike BRC-20, which is plagued by massive Bitcoin network congestion, high fees, and indexer centralization, Kasplex utilizes a lightweight indexing protocol and is backed by Kaspa's high-throughput architecture, resulting in fractions of a cent in fees and instantaneous confirmation.

### 2. What makes KRC-20 minting "fair"?
All deployments on Kasplex are fully subject to open market rules. The deployer cannot lock tokens for themselves or prevent other users from minting. Anyone who pays the tiny network fee can mint blocks of tokens until the supply cap is completed.

### 3. How do I bridge other assets to Kaspa?
Through **BridgeX**, our cross-chain decentralized gateway, you can wrap assets like USDT, ETH, and BTC and send them to your Kaspa address, where they will reside as high-performance KRC-20 wrapped assets.

### 4. Can I build smart contracts on Kasplex?
Yes! The **Kasplex zkEVM Layer** provides full EVM compatibility. You can deploy Solidity contracts, build AMMs, create yield protocols, or write complex gaming contracts with absolute ease.
`
  }
];
