import React, { useState } from 'react';
import { EcosystemProject } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Share2, ThumbsUp, Globe, Plus, X, Check, HelpCircle } from 'lucide-react';

interface EcosystemBuildersProps {
  projects: EcosystemProject[];
  onAddProject: (project: EcosystemProject) => void;
}

type FilterCategory = 'All' | 'DeFi' | 'NFTs' | 'Infrastructure' | 'Wallets';

export const EcosystemBuilders: React.FC<EcosystemBuildersProps> = ({
  projects,
  onAddProject
}) => {
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('All');
  const [likedIds, setLikedIds] = useState<string[]>([]);
  const [sharedIds, setSharedIds] = useState<string[]>([]);
  
  // Project Form Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [projName, setProjName] = useState('');
  const [projCategory, setProjCategory] = useState<'DeFi' | 'NFTs' | 'Infrastructure' | 'Wallets'>('DeFi');
  const [projDesc, setProjDesc] = useState('');
  const [projWebsite, setProjWebsite] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);

  const handleLike = (id: string) => {
    if (likedIds.includes(id)) {
      setLikedIds(likedIds.filter(x => x !== id));
    } else {
      setLikedIds([...likedIds, id]);
    }
  };

  const handleShare = (id: string) => {
    if (sharedIds.includes(id)) return;
    setSharedIds([...sharedIds, id]);
    
    // Simulate copying to clipboard
    navigator.clipboard?.writeText(`https://kasplex.org/ecosystem/${id}`).then(() => {
      // Done
    }).catch(() => {});
    
    setTimeout(() => {
      setSharedIds(prev => prev.filter(x => x !== id));
    }, 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName.trim() || !projDesc.trim()) return;

    // Pick a high-quality placeholder logo icon depending on the category
    const categoryPlaceholders: Record<string, string> = {
      DeFi: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBCxT_JpfIdlZOy8dlwNRt-MYmYpiE6d2opeB1kkIBLop8QRtH7zvY_4h7dadxuEsp5TI-T14s9YpP2VlvkrUQjcem1K2hFMqcItuqeetepnBnutJrXs7Qv35jDYXxHbSpSpXJ3k8H_b2BJ7LGK0QN8Ww3EgOnhVrFG231pdm4ArnLy8ffeSqZncVvJy4wU77e4gxqmPJbNSSybvsn2mp35qCwmJP4j6HuRtbbucCcvo8IHjVUr8pMM8mGTltA-LdxBZYoJ3zRbhQo',
      NFTs: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3kw6u9k85Y24tv4WK4UHxDsa_BhoK7VZugZSJqLlho2OOmTB_QBBW7Lqanivnb8yNWSDTeh0z14L3IHhi7y3XSQROuDqTf9VOLLBLs8nY0f8iB8xYzvd1w4-u6etp9fDRs7atz8mYHNrLLWchEFnWabHxivVaiwBMylIdixqFwidwPqhdEPB0zGNbSTYLVsHzkdc2-BmPKOXWbeHiMI6dxo0NdRFiPOKpFQ-2cnpmrWuvGqWldMrZc0Gc5vrf5fEWRcbs9FHD080',
      Infrastructure: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCp_moSMvXYbvGxN8L_C5aKojmLf0U6eBhKZHAe3rS_IdSIMqvQJ3yxDN85604UCcyhXzZCI1CgdDEvtdegDsZW8m_FLjQWUJas6xbvGiM6gf2lZuYesXrBmCq_nZ4_r7ZUxLzxXyA1FkaVR8_D6kPMV1CFCFPiHRODKPHVvH2_WuuZisFrA0UXswfbeDnm1AWX4vx8SLqZpddDQIJl66i3fOf89OotnbN3gwuV4KpNu9ADVW9FDz7W_L5NUGNJADsQptDEHqnNVV0',
      Wallets: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB7Q9rdNmWfbH_cB6eukU-fc6d8ku6ch7YAkYtGifUV-ppexbzqquSgZXbBECxkHVRRDVmOIJ11sLT3fOqnWgxSJnLeZx_b3fzDPkKiR7EATgTJMYWD3iY1pG94nvNdaGPopEfNO4xXB4h_qfPiNeSlTDddhUEAo0xXmtJxxvzPml-MRp13ZQOOfKd9i69Tn15Qr0B2gFLVOgD0PiDpiPyidSsyQU2ZkWfjAu2dBU7A2KCLU-JTpDvBSkh0yu2f7WaTiP-da0ZIa9k'
    };

    const newProj: EcosystemProject = {
      id: `custom_${Date.now()}`,
      name: projName,
      category: projCategory,
      description: projDesc,
      logoUrl: categoryPlaceholders[projCategory],
      websiteUrl: projWebsite || '#',
      shares: 0,
      likes: 0
    };

    onAddProject(newProj);
    setFormSuccess(true);
    setTimeout(() => {
      setFormSuccess(false);
      setIsModalOpen(false);
      setProjName('');
      setProjDesc('');
      setProjWebsite('');
    }, 1500);
  };

  const filteredProjects = activeFilter === 'All'
    ? projects
    : projects.filter(p => p.category === activeFilter);

  const filterTabs: FilterCategory[] = ['All', 'DeFi', 'NFTs', 'Infrastructure', 'Wallets'];

  return (
    <div id="ecosystem-builders-panel" class="space-y-6">
      
      {/* Filters and Add Button */}
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-surface-container/40 p-3 rounded-2xl border border-outline-variant/30">
        <div class="flex flex-wrap gap-1.5">
          {filterTabs.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveFilter(tab)}
              class={`px-3.5 py-1.5 rounded-xl font-headline text-xs font-semibold tracking-wide transition-all ${
                activeFilter === tab
                  ? 'bg-primary text-background shadow-lg shadow-primary/10'
                  : 'text-outline hover:text-[#e2e2e2] hover:bg-surface-container-high'
              }`}
              id={`filter-tab-${tab.toLowerCase()}`}
            >
              {tab}
            </button>
          ))}
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          class="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-surface-container-high hover:bg-surface-bright text-[#e2e2e2] hover:text-primary rounded-xl font-headline font-semibold text-xs transition-all border border-outline-variant/50 cursor-pointer self-start sm:self-auto"
          id="open-add-project-modal"
        >
          <Plus size={14} />
          Register Your dApp
        </button>
      </div>

      {/* Grid List */}
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredProjects.map(project => {
            const hasLiked = likedIds.includes(project.id);
            const hasShared = sharedIds.includes(project.id);

            return (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.25 }}
                class="glass-card rounded-2xl p-5 flex flex-col justify-between border-outline-variant hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 transition-all group relative overflow-hidden"
              >
                <div>
                  <div class="flex items-start justify-between gap-4 mb-4">
                    <div class="flex items-center gap-3.5">
                      <div class="w-12 h-12 rounded-xl bg-surface-container overflow-hidden border border-outline-variant flex items-center justify-center group-hover:border-primary/40 transition-colors shrink-0">
                        <img 
                          src={project.logoUrl} 
                          alt={`${project.name} Logo`} 
                          class="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <h4 class="font-headline font-semibold text-base text-[#e2e2e2] group-hover:text-primary transition-colors">
                          {project.name}
                        </h4>
                        <span class="inline-block px-2 py-0.5 mt-1 rounded bg-primary-container/10 border border-primary/20 text-primary font-mono text-[9px] uppercase tracking-wider">
                          {project.category}
                        </span>
                      </div>
                    </div>

                    <a 
                      href={project.websiteUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      class="p-2 rounded-lg bg-surface-container hover:bg-surface-container-high border border-outline-variant hover:border-outline text-outline hover:text-[#e2e2e2] transition-all"
                      title="Visit Website"
                    >
                      <Globe size={14} />
                    </a>
                  </div>

                  <p class="text-xs text-outline leading-relaxed mb-5">
                    {project.description}
                  </p>
                </div>

                {/* Interactions footer */}
                <div class="flex items-center justify-between pt-3 border-t border-outline-variant/30 text-outline font-mono text-xs">
                  <div class="flex items-center gap-4">
                    {/* Like Trigger */}
                    <button 
                      onClick={() => handleLike(project.id)}
                      class={`inline-flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-surface-container-high transition-colors ${
                        hasLiked ? 'text-[#ff4d4d]' : 'hover:text-primary'
                      }`}
                      title={hasLiked ? 'Unlike Project' : 'Like Project'}
                    >
                      <ThumbsUp size={13} class={hasLiked ? 'fill-current' : ''} />
                      <span>{project.likes + (hasLiked ? 1 : 0)}</span>
                    </button>

                    {/* Share Trigger */}
                    <button 
                      onClick={() => handleShare(project.id)}
                      class={`inline-flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-surface-container-high transition-colors ${
                        hasShared ? 'text-primary' : 'hover:text-primary'
                      }`}
                      title="Copy Project Link"
                    >
                      {hasShared ? <Check size={13} /> : <Share2 size={13} />}
                      <span>{hasShared ? 'Copied' : project.shares}</span>
                    </button>
                  </div>

                  <span class="text-[10px] text-outline-variant">ID: {project.id.toUpperCase().substring(0, 8)}</span>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Add Project Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Overlay backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              class="absolute inset-0 bg-[#000000]/70 backdrop-blur-md"
            ></motion.div>

            {/* Modal Box */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              class="bg-surface-raised border border-outline-variant rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl relative z-10"
            >
              <div class="bg-surface-container px-6 py-4 border-b border-outline-variant flex justify-between items-center">
                <h3 class="font-headline font-semibold text-sm uppercase tracking-wide text-[#e2e2e2] flex items-center gap-2">
                  <Plus size={16} class="text-primary" />
                  Submit Your Kasplex Integration
                </h3>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  class="p-1 rounded hover:bg-surface-container-high text-outline hover:text-[#e2e2e2] transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              <div class="p-6">
                {formSuccess ? (
                  <div class="text-center py-6">
                    <div class="w-12 h-12 rounded-full bg-primary/10 border border-primary/20 text-primary flex items-center justify-center mx-auto mb-4">
                      <Check size={24} />
                    </div>
                    <h4 class="font-headline font-semibold text-base text-[#e2e2e2] mb-1">Registration Complete!</h4>
                    <p class="text-xs text-outline">Your dApp registry request is being processed. It will display live immediately.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} class="space-y-4">
                    <div>
                      <label class="block text-xs font-mono text-outline mb-1.5">Project Name</label>
                      <input 
                        type="text"
                        required
                        value={projName}
                        onChange={(e) => setProjName(e.target.value)}
                        placeholder="e.g. KasQuest NFT Hub"
                        class="w-full bg-surface-container border border-outline-variant rounded-lg px-3 py-2 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono"
                      />
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label class="block text-xs font-mono text-outline mb-1.5">Category</label>
                        <select 
                          value={projCategory}
                          onChange={(e) => setProjCategory(e.target.value as any)}
                          class="w-full bg-surface-container border border-outline-variant rounded-lg px-3 py-2 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono"
                        >
                          <option value="DeFi">DeFi</option>
                          <option value="NFTs">NFTs</option>
                          <option value="Infrastructure">Infrastructure</option>
                          <option value="Wallets">Wallets</option>
                        </select>
                      </div>

                      <div>
                        <label class="block text-xs font-mono text-outline mb-1.5">Website URL (Optional)</label>
                        <input 
                          type="text"
                          value={projWebsite}
                          onChange={(e) => setProjWebsite(e.target.value)}
                          placeholder="e.g. https://kasquest.io"
                          class="w-full bg-surface-container border border-outline-variant rounded-lg px-3 py-2 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label class="block text-xs font-mono text-outline mb-1.5">Brief Description</label>
                      <textarea 
                        required
                        value={projDesc}
                        onChange={(e) => setProjDesc(e.target.value)}
                        placeholder="Provide a short description detailing how your project utilizes or extends Kasplex meta-assets."
                        rows={3}
                        class="w-full bg-surface-container border border-outline-variant rounded-lg p-3 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono resize-none"
                      ></textarea>
                    </div>

                    <button 
                      type="submit"
                      class="w-full py-2.5 bg-primary text-background hover:bg-[#8dd2d5] font-headline font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-primary/10 mt-2 cursor-pointer"
                    >
                      Submit Registration
                    </button>
                  </form>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
