import React, { useState } from 'react';
import { TokenInfo, MintTransaction } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Cpu, CheckCircle, ArrowRight, HelpCircle, AlertCircle, RefreshCw } from 'lucide-react';

interface DeployTokenFormProps {
  onDeploySuccess: (newToken: TokenInfo) => void;
  onAddTransaction: (tx: MintTransaction) => void;
}

export const DeployTokenForm: React.FC<DeployTokenFormProps> = ({
  onDeploySuccess,
  onAddTransaction
}) => {
  const [name, setName] = useState('');
  const [ticker, setTicker] = useState('');
  const [totalSupply, setTotalSupply] = useState('100000000');
  const [mintLimit, setMintLimit] = useState('1000');
  const [creatorAddress, setCreatorAddress] = useState('kaspa:qr3u77sh9...2wpx4');
  
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployResult, setDeployResult] = useState<TokenInfo | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Validate the ticker rules
  const getTickerValidationMsg = () => {
    if (!ticker) return null;
    if (ticker.length < 4 || ticker.length > 6) {
      return 'Ticker must be between 4 and 6 characters.';
    }
    if (!/^[A-Z]+$/.test(ticker)) {
      return 'Ticker must contain uppercase letters (A-Z) only.';
    }
    return null;
  };

  const generateRandomAddress = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let rand = '';
    for (let i = 0; i < 24; i++) {
      rand += chars[Math.floor(Math.random() * chars.length)];
    }
    setCreatorAddress(`kaspa:qp${rand.substring(0, 8)}...${rand.substring(16, 24)}`);
  };

  const handleDeploy = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Run validations
    if (!name.trim()) {
      setErrorMsg('Token name is required.');
      return;
    }

    const tickerErr = getTickerValidationMsg();
    if (tickerErr) {
      setErrorMsg(tickerErr);
      return;
    }

    const supply = Number(totalSupply);
    const limit = Number(mintLimit);

    if (isNaN(supply) || supply <= 0) {
      setErrorMsg('Total supply must be a valid number greater than 0.');
      return;
    }

    if (isNaN(limit) || limit <= 0) {
      setErrorMsg('Limit per mint must be a valid number greater than 0.');
      return;
    }

    if (limit > supply) {
      setErrorMsg('Limit per mint cannot exceed the total supply.');
      return;
    }

    setIsDeploying(true);

    // Simulate transaction submission and zk-Proof generation
    setTimeout(() => {
      const newToken: TokenInfo = {
        name: name.trim(),
        ticker: ticker.toUpperCase(),
        supply,
        limit,
        deployedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        creator: creatorAddress
      };

      // Create a DEPLOY transaction record
      const txId = `tx_${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`;
      const deployTx: MintTransaction = {
        id: txId,
        type: 'DEPLOY',
        asset: newToken.ticker,
        status: 'SUCCESS',
        timestamp: 'Just now'
      };

      // Update parent states
      onDeploySuccess(newToken);
      onAddTransaction(deployTx);

      setDeployResult(newToken);
      setIsDeploying(false);

      // Reset fields
      setName('');
      setTicker('');
    }, 2000);
  };

  return (
    <div id="deploy-token-form" class="glass-card rounded-2xl border-outline-variant overflow-hidden">
      <div class="bg-surface-container px-6 py-4 border-b border-outline-variant flex justify-between items-center">
        <h3 class="font-headline font-semibold text-base text-[#e2e2e2] flex items-center gap-2">
          <Cpu size={18} class="text-primary" />
          KRC-20 Protocol Builder
        </h3>
        <span class="text-[10px] font-mono text-outline-variant">ID: KRC20_DEPLOY_SYS_V1</span>
      </div>

      <div class="p-6">
        <AnimatePresence mode="wait">
          {!deployResult ? (
            <motion.form 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onSubmit={handleDeploy} 
              class="space-y-4"
            >
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Token Name Input */}
                <div>
                  <label class="block text-xs font-mono text-outline mb-1.5">Token Full Name</label>
                  <input 
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Space Hash"
                    class="w-full bg-surface-container border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-colors"
                  />
                </div>

                {/* Ticker Input */}
                <div>
                  <div class="flex justify-between items-center mb-1.5">
                    <label class="block text-xs font-mono text-outline">Ticker Symbol</label>
                    <span class="text-[10px] text-outline-variant font-mono">4-6 Capital Letters</span>
                  </div>
                  <input 
                    type="text"
                    value={ticker}
                    onChange={(e) => setTicker(e.target.value.toUpperCase())}
                    placeholder="e.g. SHASH"
                    maxLength={6}
                    class="w-full bg-surface-container border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-colors"
                  />
                  {getTickerValidationMsg() && (
                    <p class="text-[10px] text-error-red mt-1 font-mono flex items-center gap-1">
                      <AlertCircle size={10} />
                      {getTickerValidationMsg()}
                    </p>
                  )}
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Total Supply Input */}
                <div>
                  <label class="block text-xs font-mono text-outline mb-1.5">Maximum Total Supply</label>
                  <input 
                    type="number"
                    value={totalSupply}
                    onChange={(e) => setTotalSupply(e.target.value)}
                    placeholder="21000000"
                    class="w-full bg-surface-container border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-colors"
                  />
                </div>

                {/* Mint Limit Input */}
                <div>
                  <label class="block text-xs font-mono text-outline mb-1.5">Limit Per Single Mint</label>
                  <input 
                    type="number"
                    value={mintLimit}
                    onChange={(e) => setMintLimit(e.target.value)}
                    placeholder="1000"
                    class="w-full bg-surface-container border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-colors"
                  />
                </div>
              </div>

              {/* Creator Address Input */}
              <div>
                <div class="flex justify-between items-center mb-1.5">
                  <label class="block text-xs font-mono text-outline">Creator Receiving Address</label>
                  <button 
                    type="button"
                    onClick={generateRandomAddress}
                    class="text-[11px] text-primary hover:underline font-mono flex items-center gap-1"
                  >
                    <RefreshCw size={11} />
                    Regen Address
                  </button>
                </div>
                <input 
                  type="text"
                  value={creatorAddress}
                  onChange={(e) => setCreatorAddress(e.target.value)}
                  class="w-full bg-surface-container border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-outline-variant focus:outline-none focus:border-primary font-mono"
                />
              </div>

              {errorMsg && (
                <div class="p-3 bg-error-red/10 border border-error-red/20 text-error-red rounded-lg text-xs font-mono flex items-start gap-2">
                  <AlertCircle size={14} class="shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button 
                type="submit"
                disabled={isDeploying}
                class="w-full py-3 bg-primary text-background hover:bg-[#8dd2d5] active:scale-[0.99] disabled:opacity-50 disabled:scale-100 font-headline font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/10 mt-2"
                id="deploy-submit-btn"
              >
                {isDeploying ? (
                  <>
                    <span class="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin"></span>
                    Hashing Blocks & Generating Proofs...
                  </>
                ) : (
                  <>
                    Deploy KRC-20 Token
                    <ArrowRight size={14} />
                  </>
                )}
              </button>
            </motion.form>
          ) : (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              class="text-center py-8 px-4"
            >
              <div class="w-16 h-16 rounded-full bg-primary/10 text-primary border border-primary/20 flex items-center justify-center mx-auto mb-5">
                <CheckCircle size={32} />
              </div>
              
              <h4 class="font-headline font-bold text-xl text-[#e2e2e2] mb-2">Token Successfully Deployed!</h4>
              <p class="text-xs text-outline max-w-md mx-auto mb-6">
                Your new KRC-20 standard token has been compiled, hashed, and committed directly onto the Kaspa BlockDAG. It is now open for public or private minting!
              </p>

              <div class="max-w-md mx-auto bg-surface-container-low border border-outline-variant/50 rounded-xl p-4 text-left font-mono text-xs mb-6 space-y-2">
                <div class="flex justify-between border-b border-outline-variant/20 pb-1.5">
                  <span class="text-outline">Name:</span>
                  <span class="text-[#e2e2e2] font-semibold">{deployResult.name}</span>
                </div>
                <div class="flex justify-between border-b border-outline-variant/20 pb-1.5">
                  <span class="text-outline">Ticker:</span>
                  <span class="text-primary font-bold">{deployResult.ticker}</span>
                </div>
                <div class="flex justify-between border-b border-outline-variant/20 pb-1.5">
                  <span class="text-outline">Max Supply:</span>
                  <span class="text-[#e2e2e2]">{deployResult.supply.toLocaleString()}</span>
                </div>
                <div class="flex justify-between border-b border-outline-variant/20 pb-1.5">
                  <span class="text-outline">Limit Per Mint:</span>
                  <span class="text-[#e2e2e2]">{deployResult.limit.toLocaleString()}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-outline">Creator:</span>
                  <span class="text-outline-variant truncate w-40 text-right">{deployResult.creator}</span>
                </div>
              </div>

              <button 
                onClick={() => setDeployResult(null)}
                class="px-6 py-2 bg-surface-container-high border border-outline hover:border-primary hover:text-primary rounded-lg text-xs font-semibold transition-colors"
                id="deploy-another-btn"
              >
                Deploy Another Token
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
