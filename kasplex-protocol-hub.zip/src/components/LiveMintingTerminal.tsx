import React, { useState, useEffect, useRef } from 'react';
import { MintTransaction, TokenInfo } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, 
  Cpu, 
  Layers, 
  TrendingUp, 
  Zap, 
  Clock, 
  CircleDot, 
  Play, 
  Pause, 
  RotateCcw,
  CheckCircle2, 
  Activity,
  PlusCircle
} from 'lucide-react';

interface LiveMintingTerminalProps {
  tokens: TokenInfo[];
  transactions: MintTransaction[];
  onAddTransaction: (tx: MintTransaction) => void;
  onMintSuccess: (ticker: string, amount: number) => void;
}

export const LiveMintingTerminal: React.FC<LiveMintingTerminalProps> = ({
  tokens,
  transactions,
  onAddTransaction,
  onMintSuccess
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [selectedTicker, setSelectedTicker] = useState<string>('KASP');
  const [mintAmount, setMintAmount] = useState<number>(1000);
  const [isMinting, setIsMinting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  
  // Terminal scrolling support
  const feedEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (feedEndRef.current) {
      feedEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [transactions]);

  // Handle simulated streaming transactions
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      // Pick a random token from the available list
      const randomToken = tokens[Math.floor(Math.random() * tokens.length)];
      const randomType = Math.random() > 0.35 ? 'MINT' : (Math.random() > 0.5 ? 'TRANSFER' : 'DEPLOY');
      
      const txId = `tx_${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`;
      
      let newTx: MintTransaction;
      if (randomType === 'DEPLOY') {
        const tempTickers = ['ALPHA', 'KMAX', 'OMEGA', 'DAGGER', 'BLOCK', 'KRCX'];
        const randomNewTicker = tempTickers[Math.floor(Math.random() * tempTickers.length)];
        newTx = {
          id: txId,
          type: 'DEPLOY',
          asset: randomNewTicker,
          status: 'SUCCESS',
          timestamp: 'Just now'
        };
      } else {
        const randomAmount = Math.floor(Math.random() * randomToken.limit) + 1;
        newTx = {
          id: txId,
          type: randomType,
          asset: randomToken.ticker,
          amount: `${randomAmount.toLocaleString()} ${randomToken.ticker}`,
          status: Math.random() > 0.1 ? 'SUCCESS' : 'FAILED',
          timestamp: 'Just now'
        };

        if (randomType === 'MINT' && newTx.status === 'SUCCESS') {
          onMintSuccess(randomToken.ticker, randomAmount);
        }
      }

      onAddTransaction(newTx);
    }, 4500);

    return () => clearInterval(interval);
  }, [isPlaying, tokens, onAddTransaction, onMintSuccess]);

  // Handle manual mint trigger
  const handleManualMint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicker) return;

    const targetToken = tokens.find(t => t.ticker === selectedTicker);
    const limit = targetToken ? targetToken.limit : 1000;

    if (mintAmount <= 0) {
      alert('Mint amount must be greater than 0');
      return;
    }

    if (mintAmount > limit) {
      alert(`Mint amount exceeds the maximum single mint limit of ${limit.toLocaleString()} for ${selectedTicker}`);
      return;
    }

    setIsMinting(true);
    setSuccessMsg(null);

    // Simulate cryptographic processing time
    setTimeout(() => {
      const txId = `tx_${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`;
      const newTx: MintTransaction = {
        id: txId,
        type: 'MINT',
        asset: selectedTicker,
        amount: `${mintAmount.toLocaleString()} ${selectedTicker}`,
        status: 'SUCCESS',
        timestamp: 'Just now'
      };

      onAddTransaction(newTx);
      onMintSuccess(selectedTicker, mintAmount);
      
      setIsMinting(false);
      setSuccessMsg(`Successfully broadcasted mint instruction for ${mintAmount.toLocaleString()} ${selectedTicker}!`);
      
      setTimeout(() => setSuccessMsg(null), 4000);
    }, 1500);
  };

  // Compute live aggregates from transactions
  const successTxs = transactions.filter(t => t.status === 'SUCCESS');
  const totalMints = successTxs.filter(t => t.type === 'MINT').length;
  const totalDeploys = successTxs.filter(t => t.type === 'DEPLOY').length;
  const totalTransfers = successTxs.filter(t => t.type === 'TRANSFER').length;

  return (
    <div id="live-minting-terminal" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Terminal Block */}
      <div class="lg:col-span-2 glass-card rounded-2xl overflow-hidden flex flex-col h-[520px] relative border-outline-variant">
        {/* Top bar */}
        <div class="bg-surface-container px-4 py-3 border-b border-outline-variant flex items-center justify-between">
          <div class="flex items-center gap-2">
            <div class="flex gap-1.5">
              <span class="w-3 h-3 rounded-full bg-error-red/80"></span>
              <span class="w-3 h-3 rounded-full bg-warning-amber/80"></span>
              <span class="w-3 h-3 rounded-full bg-[#62d7de]/80"></span>
            </div>
            <span class="font-mono text-xs text-outline ml-3 flex items-center gap-1.5">
              <Terminal size={14} class="text-primary animate-pulse" />
              kasplex-indexer-v1.0.4@live-dag
            </span>
          </div>
          
          <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-primary-container/20 border border-primary/20 text-primary font-mono text-[10px]">
              <span class="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
              LIVE CONNECTED
            </span>
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              class="p-1 rounded hover:bg-surface-container-high text-outline hover:text-primary transition-colors"
              title={isPlaying ? 'Pause Feed Stream' : 'Resume Feed Stream'}
              id="pause-resume-stream"
            >
              {isPlaying ? <Pause size={14} /> : <Play size={14} />}
            </button>
          </div>
        </div>

        {/* Live log list */}
        <div class="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-2.5 custom-scrollbar bg-surface-deep/80 relative">
          <div class="scanline"></div>
          
          <div class="text-[#869394] border-b border-outline-variant/30 pb-2 mb-3">
            [SYS_INIT] Initializing Kasplex consensus state verification...<br />
            [SYS_INIT] GHOSTDAG topological sorting synced at height #48,102,120.<br />
            [SYS_INIT] Listening for KRC-20 UTXO transaction envelops...
          </div>

          <AnimatePresence initial={false}>
            {transactions.map((tx, idx) => (
              <motion.div
                key={tx.id + idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                class="flex flex-col sm:flex-row sm:items-center justify-between p-2 rounded bg-surface-container-low/40 hover:bg-surface-container-low border border-outline-variant/15 transition-all"
              >
                <div class="flex items-center gap-2.5 flex-wrap">
                  <span class="text-outline-variant">[{tx.timestamp}]</span>
                  <span class={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                    tx.type === 'DEPLOY' ? 'bg-[#ffb800]/10 text-[#ffb800] border border-[#ffb800]/20' :
                    tx.type === 'MINT' ? 'bg-[#62d7de]/10 text-[#62d7de] border border-[#62d7de]/20' :
                    'bg-[#8dd2d5]/10 text-[#8dd2d5] border border-[#8dd2d5]/20'
                  }`}>
                    {tx.type}
                  </span>
                  
                  <span class="text-[#e2e2e2]">
                    {tx.type === 'DEPLOY' ? (
                      <span>Registered ticker <strong class="text-primary font-bold">{tx.asset}</strong></span>
                    ) : (
                      <span>Processed <strong class="text-[#e2e2e2] font-semibold">{tx.amount}</strong></span>
                    )}
                  </span>
                </div>

                <div class="flex items-center gap-3 mt-1 sm:mt-0 font-mono text-[11px] text-outline">
                  <span>ID: {tx.id}</span>
                  <span class={`flex items-center gap-1 ${
                    tx.status === 'SUCCESS' ? 'text-primary' : 
                    tx.status === 'PENDING' ? 'text-warning-amber animate-pulse' : 
                    'text-error-red'
                  }`}>
                    <CircleDot size={8} class="fill-current" />
                    {tx.status}
                  </span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          <div ref={feedEndRef} />
        </div>
      </div>

      {/* Interactive Controls & Stats */}
      <div class="flex flex-col gap-6">
        
        {/* Statistics Block */}
        <div class="glass-card rounded-2xl p-5 border-outline-variant">
          <h3 class="font-headline font-semibold text-sm uppercase tracking-wider text-outline mb-4 flex items-center gap-2">
            <Activity size={16} class="text-primary" />
            Consensus Aggregates
          </h3>
          
          <div class="grid grid-cols-2 gap-4">
            <div class="bg-surface-container-low p-3.5 rounded-xl border border-outline-variant/30">
              <span class="text-xs text-outline block mb-1">Mints Committed</span>
              <span class="text-xl font-mono font-bold text-primary flex items-center gap-1.5">
                <Layers size={16} />
                {totalMints}
              </span>
            </div>

            <div class="bg-surface-container-low p-3.5 rounded-xl border border-outline-variant/30">
              <span class="text-xs text-outline block mb-1">Tokens Deployed</span>
              <span class="text-xl font-mono font-bold text-[#ffb800] flex items-center gap-1.5">
                <Cpu size={16} />
                {totalDeploys}
              </span>
            </div>

            <div class="bg-surface-container-low p-3.5 rounded-xl border border-outline-variant/30 col-span-2">
              <div class="flex justify-between items-center mb-1">
                <span class="text-xs text-outline">L1 Network Ingest Speed</span>
                <span class="text-xs font-mono text-primary font-bold">1 BPS / 10M Gas Limit</span>
              </div>
              <div class="w-full bg-surface-container-high rounded-full h-1.5 overflow-hidden">
                <div class="bg-primary h-1.5 rounded-full animate-[pulse_1.5s_infinite]" style={{ width: '74%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Instant Mint Form */}
        <div class="glass-card rounded-2xl p-5 border-outline-variant flex-1 flex flex-col justify-between">
          <div>
            <h3 class="font-headline font-semibold text-sm uppercase tracking-wider text-outline mb-1.5 flex items-center gap-2">
              <PlusCircle size={16} class="text-primary" />
              Instant Mint Panel
            </h3>
            <p class="text-xs text-outline mb-4">
              Test the protocol! Construct a standard KRC-20 mint instruction and broadcast it instantly to the simulated BlockDAG mempool.
            </p>

            <form onSubmit={handleManualMint} class="space-y-3">
              <div>
                <label class="block text-xs font-mono text-outline mb-1.5">1. Target Token Ticker</label>
                <select 
                  value={selectedTicker}
                  onChange={(e) => {
                    setSelectedTicker(e.target.value);
                    const target = tokens.find(t => t.ticker === e.target.value);
                    if (target) setMintAmount(target.limit);
                  }}
                  class="w-full bg-surface-container border border-outline-variant rounded-lg px-3 py-2 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-all"
                  id="mint-ticker-select"
                >
                  {tokens.map(t => (
                    <option key={t.ticker} value={t.ticker}>
                      {t.ticker} ({t.name}) - Limit: {t.limit.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div class="flex justify-between text-xs font-mono text-outline mb-1">
                  <label>2. Amount to Mint</label>
                  <span class="text-primary">Max Limit: {tokens.find(t => t.ticker === selectedTicker)?.limit.toLocaleString() || '1,000'}</span>
                </div>
                <input 
                  type="number"
                  value={mintAmount}
                  onChange={(e) => setMintAmount(Number(e.target.value))}
                  class="w-full bg-surface-container border border-outline-variant rounded-lg px-3 py-2 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-all"
                  placeholder="Enter amount"
                  id="mint-amount-input"
                />
              </div>

              <button 
                type="submit" 
                disabled={isMinting}
                class="w-full py-2.5 px-4 bg-primary text-background hover:bg-[#8dd2d5] active:scale-[0.98] disabled:opacity-50 disabled:scale-100 rounded-lg font-headline font-medium text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-primary/10 mt-2"
                id="mint-submit-btn"
              >
                {isMinting ? (
                  <>
                    <span class="w-3.5 h-3.5 border-2 border-background border-t-transparent rounded-full animate-spin"></span>
                    Generating zk-Proof...
                  </>
                ) : (
                  <>
                    <Zap size={14} class="fill-current" />
                    Broadcast KRC-20 Mint
                  </>
                )}
              </button>
            </form>
          </div>

          <AnimatePresence>
            {successMsg && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                class="mt-3 p-2.5 rounded-lg bg-primary/10 border border-primary/20 text-primary text-[11px] font-mono flex items-start gap-1.5"
              >
                <CheckCircle2 size={14} class="shrink-0 mt-0.5" />
                <span>{successMsg}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
};
