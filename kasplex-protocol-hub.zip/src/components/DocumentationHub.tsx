import React, { useState } from 'react';
import { DocArticle } from '../types';
import { DOCS_ARTICLES } from '../data';
import { motion } from 'motion/react';
import { 
  Search, 
  BookOpen, 
  ChevronRight, 
  Terminal, 
  HelpCircle, 
  Cpu, 
  Sliders, 
  FileCode,
  Compass
} from 'lucide-react';

// Bespoke Markdown parser to render clean structured HTML from static docs data without external dependency issues
const renderBespokeMarkdown = (markdown: string) => {
  const lines = markdown.split('\n');
  let inCodeBlock = false;
  let codeContent: string[] = [];
  let codeLang = '';

  return lines.map((line, idx) => {
    // Code block detection
    if (line.trim().startsWith('```')) {
      if (inCodeBlock) {
        // Closing code block
        inCodeBlock = false;
        const finalCode = codeContent.join('\n');
        codeContent = [];
        return (
          <div key={idx} class="my-4 rounded-xl overflow-hidden border border-outline-variant bg-surface-deep p-4 font-mono text-xs text-[#8dd2d5] relative group">
            <div class="absolute right-3 top-2.5 text-[9px] text-outline-variant select-none uppercase tracking-wider font-mono">
              {codeLang || 'Code'}
            </div>
            <pre class="overflow-x-auto whitespace-pre custom-scrollbar">
              <code>{finalCode}</code>
            </pre>
          </div>
        );
      } else {
        // Opening code block
        inCodeBlock = true;
        codeLang = line.trim().replace('```', '');
        return null;
      }
    }

    if (inCodeBlock) {
      codeContent.push(line);
      return null;
    }

    // Header 2 (## Title)
    if (line.startsWith('## ')) {
      return (
        <h2 key={idx} class="font-headline font-bold text-lg text-[#e2e2e2] mt-6 mb-3 border-b border-outline-variant/30 pb-1 flex items-center gap-2">
          <span class="w-1 h-5 bg-primary rounded-full"></span>
          {line.replace('## ', '')}
        </h2>
      );
    }

    // Header 3 (### Subtitle)
    if (line.startsWith('### ')) {
      return (
        <h3 key={idx} class="font-headline font-semibold text-sm text-primary uppercase tracking-wide mt-4 mb-2">
          {line.replace('### ', '')}
        </h3>
      );
    }

    // Divider (---)
    if (line.trim() === '---') {
      return <hr key={idx} class="border-outline-variant/30 my-5" />;
    }

    // Bullet points (* Bullet or - Bullet)
    if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
      const cleanText = line.replace(/^[\s]*[*|-]\s+/, '');
      // Check for inline strong tags (e.g. **text**)
      const parts = cleanText.split('**');
      return (
        <ul key={idx} class="list-none space-y-1.5 pl-5 my-2">
          <li class="relative text-xs text-outline leading-relaxed before:content-['•'] before:text-primary before:absolute before:-left-4 before:font-bold">
            {parts.map((part, pIdx) => (
              pIdx % 2 === 1 ? <strong key={pIdx} class="text-[#e2e2e2] font-semibold">{part}</strong> : part
            ))}
          </li>
        </ul>
      );
    }

    // Numbered lists (1. Bullet)
    if (/^\d+\.\s+/.test(line.trim())) {
      const cleanText = line.replace(/^\d+\.\s+/, '');
      const num = line.match(/^\d+/)![0];
      const parts = cleanText.split('**');
      return (
        <ol key={idx} class="space-y-1.5 pl-6 my-2 list-none">
          <li class="relative text-xs text-outline leading-relaxed">
            <span class="absolute -left-5 text-primary font-mono text-[11px] font-bold">{num}.</span>
            {parts.map((part, pIdx) => (
              pIdx % 2 === 1 ? <strong key={pIdx} class="text-[#e2e2e2] font-semibold">{part}</strong> : part
            ))}
          </li>
        </ol>
      );
    }

    // Paragraphs
    if (line.trim() === '') {
      return null;
    }

    // General text. Parse **bold** manually
    if (line.includes('**')) {
      const parts = line.split('**');
      return (
        <p key={idx} class="text-xs text-outline leading-relaxed my-3">
          {parts.map((part, pIdx) => (
            pIdx % 2 === 1 ? <strong key={pIdx} class="text-[#e2e2e2] font-semibold">{part}</strong> : part
          ))}
        </p>
      );
    }

    return (
      <p key={idx} class="text-xs text-outline leading-relaxed my-3">
        {line}
      </p>
    );
  }).filter(el => el !== null);
};

export const DocumentationHub: React.FC = () => {
  const [selectedArticleId, setSelectedArticleId] = useState<string>('introduction');
  const [searchQuery, setSearchQuery] = useState('');

  // Get active article
  const currentArticle = DOCS_ARTICLES.find(a => a.id === selectedArticleId) || DOCS_ARTICLES[0];

  // Group articles by category
  const categories = Array.from(new Set(DOCS_ARTICLES.map(a => a.category)));

  // Filter articles based on search query
  const getFilteredArticles = (category: string) => {
    return DOCS_ARTICLES.filter(a => {
      if (a.category !== category) return false;
      if (!searchQuery) return true;
      const term = searchQuery.toLowerCase();
      return (
        a.title.toLowerCase().includes(term) ||
        a.summary.toLowerCase().includes(term) ||
        a.contentMarkdown.toLowerCase().includes(term)
      );
    });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Core Concepts':
        return <BookOpen size={15} class="text-primary" />;
      case 'Protocol Guides':
        return <Sliders size={15} class="text-[#ffb800]" />;
      default:
        return <Compass size={15} class="text-[#8dd2d5]" />;
    }
  };

  const getArticleIcon = (iconName: string) => {
    switch (iconName) {
      case 'info':
        return <BookOpen size={14} />;
      case 'token':
        return <Cpu size={14} />;
      case 'analytics':
        return <FileCode size={14} />;
      case 'settings_system_daydream':
        return <Terminal size={14} />;
      default:
        return <HelpCircle size={14} />;
    }
  };

  return (
    <div id="docs-hub-component" class="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
      
      {/* Sidebar Navigation */}
      <div class="lg:col-span-1 glass-card rounded-2xl p-4 border-outline-variant space-y-4">
        
        {/* Search bar */}
        <div class="relative">
          <Search size={14} class="absolute left-3 top-3 text-outline-variant" />
          <input 
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search docs..."
            class="w-full bg-surface-container border border-outline-variant rounded-xl pl-9 pr-3 py-2 text-xs text-[#e2e2e2] focus:outline-none focus:border-primary font-mono transition-colors"
            id="docs-search-input"
          />
        </div>

        {/* Sidebar Nav Categories */}
        <div class="space-y-4">
          {categories.map(category => {
            const filtered = getFilteredArticles(category);
            if (filtered.length === 0) return null;

            return (
              <div key={category} class="space-y-1">
                <h4 class="font-headline font-bold text-[10px] uppercase tracking-widest text-outline-variant flex items-center gap-1.5 px-2 pb-1">
                  {getCategoryIcon(category)}
                  {category}
                </h4>

                <div class="space-y-0.5">
                  {filtered.map(article => {
                    const isSelected = article.id === selectedArticleId;
                    return (
                      <button
                        key={article.id}
                        onClick={() => setSelectedArticleId(article.id)}
                        class={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left text-xs font-headline font-medium transition-all ${
                          isSelected
                            ? 'bg-primary/10 text-primary border border-primary/20'
                            : 'text-outline hover:text-[#e2e2e2] hover:bg-surface-container-high border border-transparent'
                        }`}
                        id={`doc-btn-${article.id}`}
                      >
                        <span class="flex items-center gap-2 truncate">
                          <span class={isSelected ? 'text-primary' : 'text-outline-variant'}>
                            {getArticleIcon(article.icon)}
                          </span>
                          <span class="truncate">{article.title}</span>
                        </span>
                        <ChevronRight size={10} class={`text-outline-variant transition-transform ${isSelected ? 'translate-x-0.5 text-primary' : ''}`} />
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Documentation Viewer */}
      <div class="lg:col-span-3 glass-card rounded-2xl p-6 md:p-8 border-outline-variant min-h-[500px]">
        <div class="border-b border-outline-variant/30 pb-4 mb-6">
          <div class="flex items-center gap-2 mb-2">
            <span class="text-xs font-mono text-outline-variant uppercase tracking-wider">{currentArticle.category}</span>
            <span class="w-1.5 h-1.5 rounded-full bg-outline-variant"></span>
            <span class="text-xs font-mono text-primary flex items-center gap-1">
              <Terminal size={12} />
              v1.0-KRC20
            </span>
          </div>
          
          <h1 class="font-headline font-bold text-2xl md:text-3xl text-[#e2e2e2]">
            {currentArticle.title}
          </h1>
          <p class="text-xs text-outline font-medium mt-2 leading-relaxed">
            {currentArticle.summary}
          </p>
        </div>

        {/* Content Area */}
        <div class="prose prose-invert max-w-none text-outline">
          {renderBespokeMarkdown(currentArticle.contentMarkdown)}
        </div>
      </div>

    </div>
  );
};
